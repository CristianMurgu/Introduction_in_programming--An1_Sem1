#include "butoane.h"
#include <iostream>
#include <graphics.h>
#include <wingdi.h>
#include <string>
#include <cstdio>
#include<fstream>
using namespace std;
ifstream in("data.in");
void butoane::Desen()
{
    line(xL,yUp,xL,yD);
    line(xL,yUp,xR,yUp);
    line(xL,yD,xR,yD);
    line(xR,yUp,xR,yD);
    outtextxy(xc-strlen(text)*3-2,yc-lung/4,text);
}
butoane::butoane(int x,int y,char *cuv)
{
    xc=x;
    yc=y;
    lat=strlen(cuv)*10;
    lung=30;
    xL=x-lat/2;
    xR=x+lat/2;
    yUp=y-lung/2;
    yD=y+lung/2;
    text=cuv;
}
int butoane::click(int x,int y)
{
    if(activ==1)
        if(x>=xL && x<=xR && y>=yUp && y<=yD)
            return 1;
    return 0;
}
butoane::~butoane()
{
    //dtor
}
void patrat(int x,int y)
{
    line(x-25,y-25,x+25,y-25);
    line(x-25,y+25,x+25,y+25);
    line(x+25,y-25,x+25,y+25);
    line(x-25,y-25,x-25,y+25);
}
void afisMatrice(matrice A,int xx,int yy)
{
    int stx=getmaxwidth()/45,sty=getmaxheight()/35-50;
    for(int i=1; i<=A.n; i++)
        for(int j=1; j<=A.m; j++)
        {
            char v[101];
            patrat(stx+j*50,sty+i*50);

            convertNrInCh(A.ma[i][j],v);
            outtextxy(stx+j*50-10,sty+i*50-5,v);
        }
}
void inserare(char x,char v[101],int &n)
{

    for(int i=n+1; i>0; i--)
    {
        v[i]=v[i-1];
    }
    v[0]=x;
    n++;
}

void convertNrInCh(int x,char v[101])
{
    int n=0;
    int neg=0;
    if(x<0)
    {
        neg=1;
        x=x*(-1);
    }
    v[0]=NULL;
    if(x==0)
    {
        v[0]='0';
        v[1]=NULL;
    }
    while(x)
    {
        char c=x%10;
        x=x/10;
        inserare(c+48,v,n);
    }
    if(neg)
    {
        for(int i=n+1; i>0; i--)
        {
            v[i]=v[i-1];
        }
        v[0]='-';
    }
}
void CitireTastaturaM(matrice &x,int menu)
{
    int Citire_Matrice_de_la_tastatura=initwindow(getmaxwidth()/3,getmaxheight()/3,"Citire Matrice de la tastatura",getmaxwidth()/3,getmaxheight()-250-getmaxheight()/3,false,false);
    setcurrentwindow(Citire_Matrice_de_la_tastatura);
    outtextxy(getmaxwidth()/45,getmaxheight()/35,"Numele matricei :");
    outtextxy(getmaxwidth()/45+textwidth("Numele matricei :"),getmaxheight()/35,"_");

    char v[15];
    int pv=0;
    int c=getch();

    while(c!=13)
    {
        x.nume=c;
        char v[1];
        v[0]=c;
        v[1]=NULL;
        cleardevice();
        outtextxy(getmaxwidth()/45,getmaxheight()/35,"Numele matricei :");
        outtextxy(getmaxwidth()/45+textwidth("Numele matricei :"),getmaxheight()/35,v);
        c=getch();

    }

    cleardevice();
    outtextxy(getmaxwidth()/45,getmaxheight()/35,"Lungimea matricei :");
    outtextxy(getmaxwidth()/45+textwidth("Lungimea matricei :"),getmaxheight()/35,"_");

    c=getch();
    int nr=0,neg=0;

    while(c!=13)
    {
        int cif=c;
        if(c>='0' && c<='9')
        {
            nr=nr*10+cif-'0';
            v[pv]=c;
            pv++;
            v[pv]=NULL;
        }
        if(c=='-')
        {
            v[0]='-';
            pv++;
            v[pv]=NULL;
            neg=1;
        }
        if(c==8)
        {
            nr=nr/10;
            pv--;
            v[pv]=NULL;
        }
        cleardevice();
        outtextxy(getmaxwidth()/45,getmaxheight()/35,"Lungimea matricei :");
        outtextxy(getmaxwidth()/45+textwidth("Lungimea matricei :"),getmaxheight()/35,v);
        c=getch();

    }

    x.n=nr;
    if(neg)
        std::cout<<"Eroare : Dimensiune negativa ! A fost memorat negativul numarului introdus."<<std::endl;


    cleardevice();
    outtextxy(getmaxwidth()/45,getmaxheight()/35,"Latimea matricei :");
    outtextxy(getmaxwidth()/45+textwidth("Latimea matricei :"),getmaxheight()/35,"_");

    c=getch();
    nr=0;
    neg=0;
    pv=0;

    while(c!=13)
    {
        int cif=c;
        if(c>='0' && c<='9')
        {
            nr=nr*10+cif-'0';
            v[pv]=c;
            pv++;
            v[pv]=NULL;
        }
        if(c=='-')
        {
            v[0]='-';
            pv++;
            v[pv]=NULL;
            neg=1;
        }
        if(c==8)
        {
            nr=nr/10;
            pv--;
            v[pv]=NULL;
        }
        cleardevice();
        outtextxy(getmaxwidth()/45,getmaxheight()/35,"Latimea matricei :");
        outtextxy(getmaxwidth()/45+textwidth("Latimea matricei :"),getmaxheight()/35,v);
        c=getch();
    }

    x.m=nr;

    if(neg)
        std::cout<<"Eroare : Dimensiune negativa ! A fost memorat negativul numarului introdus."<<std::endl;
    cleardevice();
    afisMatrice(x,getmaxwidth()/2,getmaxheight()/3*2);
    for(int i=1; i<=x.n; i++)
    {
        for(int j=1; j<=x.m; j++)
        {
            cleardevice();
            afisMatrice(x,getmaxwidth()/2,getmaxheight()/3*2);
            outtextxy(25,getmaxheight()/3-25,"Elementul curent : _");
            c=getch();
            nr=0;
            neg=0;
            pv=0;
            v[pv]=NULL;
            if(c=='-')
            {
                neg=1;
                v[pv]='-';
                pv++;
                v[pv]=NULL;
            }
            outtextxy(25,getmaxheight()/3-25,"Elementul curent : ");
            outtextxy(25+textwidth("elementul curent :"),getmaxheight()/3-25,v);
            while(c!=13)
            {

                int cif=c;
                if(c>='0' && c<='9')
                {
                    nr=nr*10+cif-'0';
                    v[pv]=cif;
                    pv++;
                    v[pv]=NULL;
                }
                if(c=='-')
                {
                    neg=1;

                }
                if(c==8)
                {
                    nr=nr/10;
                    pv--;
                    v[pv]=NULL;
                }

                cleardevice();
                afisMatrice(x,getmaxwidth()/2,getmaxheight()/3*2);
                outtextxy(25,getmaxheight()/3-25,"Elementul curent : ");
                outtextxy(25+textwidth("elementul curent :"),getmaxheight()/3-25,v);
                c=getch();
            }
            x.ma[i][j]=nr;
            if(neg)
                nr=nr*(-1);
            x.ma[i][j]=nr;

            afisMatrice(x,getmaxwidth()/2,getmaxheight()/3*2);
        }
    }
    delay(200);
    closegraph(CURRENT_WINDOW);
    setcurrentwindow(menu);
}

void CitireFisiertxtM(matrice &x)
{
    FILE *ptr=fopen("C:\\CodeBlocks\\IP Proiect Matrici Vectori\\Matrice.txt","r");
    x.nume=NULL;
    if(ptr!=NULL)
        fread(&x,sizeof(matrice),1,ptr);

    fclose(ptr);
}
void CitireFisierM(matrice &x)
{
    in>>x.nume;
    in>>x.n>>x.m;
    for(int i=1; i<=x.n; i++)
    {
        for(int j=1; j<=x.m; j++)
            in>>x.ma[i][j];
    }
}
void CitireTastaturaV(matrice &x,int menu)
{
    int Citire_Matrice_de_la_tastatura=initwindow(getmaxwidth(),getmaxheight()/6,"Citire Vector de la tastatura",0,getmaxheight()-250-getmaxheight()/6,false,false);
    setcurrentwindow(Citire_Matrice_de_la_tastatura);
    outtextxy(getmaxwidth()/45,getmaxheight()/35,"Numele vectorului :");
    outtextxy(getmaxwidth()/45+textwidth("Numele vectorului :"),getmaxheight()/35,"_");

    char v[15];
    int pv=0;
    int c=getch();

    while(c!=13)
    {
        x.nume=c;
        char v[1];
        v[0]=c;
        v[1]=NULL;
        cleardevice();
        outtextxy(getmaxwidth()/45,getmaxheight()/35,"Numele vectorului :");
        outtextxy(getmaxwidth()/45+textwidth("Numele vectorului :"),getmaxheight()/35,v);
        c=getch();

    }

    cleardevice();
    outtextxy(getmaxwidth()/45,getmaxheight()/35,"Lungimea vectorului :");
    outtextxy(getmaxwidth()/45+textwidth("Lungimea vectorului :"),getmaxheight()/35,"_");

    c=getch();
    int nr=0,neg=0;

    while(c!=13)
    {
        int cif=c;
        if(c>='0' && c<='9')
        {
            nr=nr*10+cif-'0';
            v[pv]=c;
            pv++;
            v[pv]=NULL;
        }
        if(c=='-')
        {
            v[0]='-';
            pv++;
            v[pv]=NULL;
            neg=1;
        }
        if(c==8)
        {
            nr=nr/10;
            pv--;
            v[pv]=NULL;
        }
        cleardevice();
        outtextxy(getmaxwidth()/45,getmaxheight()/35,"Lungimea vectorului :");
        outtextxy(getmaxwidth()/45+textwidth("Lungimea vectorului :"),getmaxheight()/35,v);
        c=getch();

    }

    x.m=nr;
    if(neg)
        std::cout<<"Eroare : Dimensiune negativa ! A fost memorat negativul numarului introdus."<<std::endl;
    x.n=1;

    if(neg)
        std::cout<<"Eroare : Dimensiune negativa ! A fost memorat negativul numarului introdus."<<std::endl;
    cleardevice();
    afisMatrice(x,getmaxwidth()/2,getmaxheight()/3*2);
    for(int i=1; i<=x.n; i++)
    {
        for(int j=1; j<=x.m; j++)
        {
            cleardevice();
            afisMatrice(x,getmaxwidth()/2,getmaxheight()/3*2);
            outtextxy(25,getmaxheight()/6-25,"Elementul curent : _");
            c=getch();
            nr=0;
            neg=0;
            pv=0;
            v[pv]=NULL;
            if(c=='-')
            {
                neg=1;
                v[pv]='-';
                pv++;
                v[pv]=NULL;
            }
            outtextxy(25,getmaxheight()/6-25,"Elementul curent : ");
            outtextxy(25+textwidth("elementul curent :"),getmaxheight()/6-25,v);
            while(c!=13)
            {

                int cif=c;
                if(c>='0' && c<='9')
                {
                    nr=nr*10+cif-'0';
                    v[pv]=cif;
                    pv++;
                    v[pv]=NULL;
                }
                if(c=='-')
                {
                    neg=1;

                }
                if(c==8)
                {
                    nr=nr/10;
                    pv--;
                    v[pv]=NULL;
                }

                cleardevice();
                afisMatrice(x,getmaxwidth()/2,getmaxheight()/3*2);
                outtextxy(25,getmaxheight()/6-25,"Elementul curent : ");
                outtextxy(25+textwidth("elementul curent :"),getmaxheight()/6-25,v);
                c=getch();
            }
            x.ma[i][j]=nr;
            if(neg)
                nr=nr*(-1);
            x.ma[i][j]=nr;

            afisMatrice(x,getmaxwidth()/2,getmaxheight()/3*2);
        }
    }
    delay(200);
    closegraph(CURRENT_WINDOW);
    setcurrentwindow(menu);
}
void CitireFisiertxtV(matrice &x)
{
    FILE *ptr=fopen("C:\\CodeBlocks\\IP Proiect Matrici Vectori\\Vector.txt","r");
    x.nume=NULL;
    if(ptr!=NULL)
        fread(&x,sizeof(matrice),1,ptr);
    fclose(ptr);
}
void CitireFisierV(matrice &x)
{
    in>>x.nume;
    in>>x.m;
    x.n=1;
    for(int j=1; j<=x.m; j++)
        in>>x.ma[1][j];
}
