#define MATH_H
#include <bits/stdc++.h>
int principal,win1=1,win2=1,win3=1,win4=1;

int size_y_dr,size_y_st;

//extern ostringstream bgiout;

//void outstreamsy(int x, int y, ostringstream& out=bgiout);

void output_nm(int m[NM][NM],int n, int m1);
void output_nn(int m[NM][NM],int n);
void elimLine(int ma[NM][NM],int &n,int m,int l)
{
    for(int i=1;i<=m;i++)
    {
            setfillstyle(LTBKSLASH_FILL, GREEN);
            floodfill(50*i+10, 50*l+10, 15);
            delay(150);
    }
    for(int i=l+1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
            ma[i-1][j]=ma[i][j];
    }
    if(n-1==m)
        output_nn(ma,n-1);
    else
        output_nm(ma,n-1,m);
    n--;
}
void elimCol(int ma[NM][NM],int n,int &m,int c)
{
    for(int i=1;i<=n;i++)
    {
            setfillstyle(LTBKSLASH_FILL, GREEN);
            floodfill(50*c+10, 50*i+10, 15);
            delay(75);
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=c+1;j<=m;j++)
            ma[i][j-1]=ma[i][j];
    }
    if(n==m-1)
        output_nn(ma,n);
    else
        output_nm(ma,n,m-1);
    m--;
}
void patrat(int x, int y,int lat)
{
    line(x-lat/2,y-lat/2,x-lat/2,y+lat/2);
    line(x-lat/2,y+lat/2,x+lat/2,y+lat/2);//jos
    line(x+lat/2,y+lat/2,x+lat/2,y-lat/2);
    line(x+lat/2,y-lat/2,x-lat/2,y-lat/2);//sus
}
void output_nm(int m[NM][NM],int n, int m1)
{
    cleardevice();
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m1;j+=2)
        {
            patrat(50*j,50*i,50);
            setfillstyle(SOLID_FILL, GREEN);
            floodfill(50*j, 50*i, 15);
            bgiout<<m[i][j];
            outstreamxy(50*j-10, 50*i-10);
            delay(150);
            setfillstyle(EMPTY_FILL, WHITE);
            floodfill(50*j+10, 50*i+10, 15);
            delay(150);
            setfillstyle(SOLID_FILL, BLACK);
            floodfill(50*j+10, 50*i+10, 15);
        }

    }
    for(int i=1;i<=n;i++)
    {
        for(int j=2;j<=m1;j+=2)
        {
            patrat(50*j,50*i,50);
            setfillstyle(SOLID_FILL, GREEN);
            floodfill(50*j, 50*i, 15);
            bgiout<<m[i][j];
            outstreamxy(50*j-10, 50*i-10);
            delay(150);
            setfillstyle(EMPTY_FILL, WHITE);
            floodfill(50*j+10, 50*i+10, 15);
            delay(150);
            setfillstyle(SOLID_FILL, BLACK);
            floodfill(50*j+10, 50*i+10, 15);
        }
    }
}
void output_nn(int m[NM][NM],int n)
{
    cleardevice();
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<i;j++)
        {
            patrat(50*j,50*i,50);
            setfillstyle(SOLID_FILL, GREEN);
            floodfill(50*j, 50*i, 15);
            bgiout<<m[i][j];
            outstreamxy(50*j-10, 50*i-10);
            delay(150);
            setfillstyle(EMPTY_FILL, WHITE);
            floodfill(50*j+10, 50*i+10, 15);
            delay(150);
            setfillstyle(SOLID_FILL, BLACK);
            floodfill(50*j+10, 50*i+10, 15);
        }
    }
    for(int i=1;i<=n;i++)
    {
        patrat(50*i,50*i,50);
        setfillstyle(SOLID_FILL, GREEN);
        floodfill(50*i, 50*i, 15);
        bgiout<<m[i][i];
        outstreamxy(50*i-10, 50*i-10);
        delay(150);
        setfillstyle(EMPTY_FILL, WHITE);
        floodfill(50*i+10, 50*i+10, 15);
        delay(150);
        setfillstyle(SOLID_FILL, BLACK);
        floodfill(50*i+10, 50*i+10, 15);
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            patrat(50*j,50*i,50);
            setfillstyle(SOLID_FILL, GREEN);
            floodfill(50*j, 50*i, 15);
            bgiout<<m[i][j];
            outstreamxy(50*j-10, 50*i-10);
            delay(150);
            setfillstyle(EMPTY_FILL, WHITE);
            floodfill(50*j+10, 50*i+10, 15);
            delay(150);
            setfillstyle(SOLID_FILL, BLACK);
            floodfill(50*j+10, 50*i+10, 15);
        }
    }
}
bool t=0;
void transpusa(int m[NM][NM], int n, bool ok)
{
    for(int i=1;i<=n && t==0;i++)
    {
        m[i][i]=m[i][i];
        for(int j=i+1;j<=n;j++)
        {
            if(i!=j)
                swap(m[i][j],m[j][i]);
        }
    }
    t=1;
    if(ok==1)
        output_nn(m,n);
}

int det(int m[NM][NM], int n);

int detij(int m[NM][NM],int l, int c, int n)
{
    int a[NM][NM];
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            if(i>=l+1)
                a[i-1][j]=m[i][j];
            else
                a[i][j]=m[i][j];
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=c+1;j<=n;j++)
            a[i][j-1]=a[i][j];
    }
    return det(a,n-1);
}

int det(int m[NM][NM], int n)
{
    switch (n)
    {
    case 1:
        return m[1][1];
    case 2:
        return m[1][1]*m[2][2]-m[2][1]*m[1][2];
    case 3:
        {
            int sf=0,df=0,aux1,aux2;
            for(int i=n+1;i<=2*n-1;i++)
            {
                for(int j=1;j<=n;j++)
                    m[i][j]=m[i-n][j];
            }
            for(int i=0;i<n;i++)
            {
                aux1=1;
                aux2=1;
                for(int j=1, k=n; j<=n && k>=1;j++, k--)
                {
                    aux1=aux1*m[j+i][j];
                    aux2=aux2*m[j+i][k];
                }
                sf=sf+aux1;
                df=df+aux2;
            }
            return sf-df;
        }
    default:
        {
            int s=0;
            for(int i=1;i<=n;i++)
                s=s+pow(-1,i+1)*m[1][i]*detij(m,1,i,n);
                return s;
        }
    }
}

void inversa(int m[NM][NM], int n)
{
    int d=det(m,n);
    transpusa(m,n,0);
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            mi[i][j]=pow(-1,i+j)*detij(m,i,j,n)/d;
    }
    output_nn(mi,n);
}

void generate_inversa(int ma[NM][NM],int n)
{
    if(win1!=1)
    {
        setcurrentwindow(win1);
        closegraph(win1);
    }
    if(size_y_st+n*50+50>(getmaxheight()-250))
    {
        if(win3!=1)
        {
            setcurrentwindow(win3);
            closegraph(win3);
        }
        size_y_st=0;
    }
    win1= initwindow(n*50+50,n*50+50,"inversa matricii", 0, 0, false, false);
    size_y_st+=n*50+50;
    setbkcolor(4);
    cleardevice();
    inversa(ma,n);
}

void generate_transpusa(int ma[NM][NM], int n)
{
    if(win2!=1)
    {
        setcurrentwindow(win2);
        closegraph(win2);
    }
    if(size_y_dr+n*50+50>(getmaxheight()-250))
    {
        if(win4!=1)
        {
            setcurrentwindow(win4);
            closegraph(win4);
        }
        size_y_dr=0;
    }
    win2= initwindow(n*50+50,n*50+50,"transpusa matricii",getmaxwidth()-(n*50+50),0,false,false);
    size_y_dr+=n*50+50;
    setbkcolor(4);
    cleardevice();
    transpusa(ma,n,1);
}

void generate_eliminari(int ma[NM][NM], int &n, int &m, bool ok, int v)
{
    if(win3!=1)
    {
        setcurrentwindow(win3);
        closegraph(win3);
    }
    if(ok)
    {
        if(size_y_st+n*50+50>(getmaxheight()-250))
        {
            if(win1!=1)
            {
                setcurrentwindow(win1);
                closegraph(win1);
            }
            size_y_st=0;
        }
        win3= initwindow(m*50+50,n*50+50,"eliminari linie",0,size_y_st,false,false);
        size_y_st+=n*50+50;
    }
    else
    {
        if(size_y_dr+n*50+50>(getmaxheight()-250))
        {
            if(win2!=1)
            {
                setcurrentwindow(win2);
                closegraph(win2);
            }
            size_y_dr=0;
            ok=1;
        }
        win3= initwindow(m*50+50,n*50+50,"eliminari coloana",getmaxwidth()-((m+1)*50),size_y_dr,false,false);
        if(ok)
            size_y_dr+=n*50+50;
    }
    setbkcolor(4);
    cleardevice();
    output_nm(ma,n,m);
    if(ok)
        elimLine(ma,n,m,v);
    else
        elimCol(ma,n,m,v);
}

void generate_m2(int ma[NM][NM], int n, int m)
{
    if(win4!=1)
    {
        setcurrentwindow(win4);
        closegraph(win4);
    }
    if((win1!=1 || win2!=1) && (max(size_y_dr,size_y_st)+n*50+50)>getmaxheight())
    {
        setcurrentwindow(win1);
        closegraph(win1);
        setcurrentwindow(win2);
        closegraph(win2);
        win1=win2=1;
        size_y_dr=size_y_st=0;
    }
    size_y_st=max(size_y_dr,size_y_st);
    size_y_dr=max(size_y_dr,size_y_st);
    win4= initwindow(m*50+50,n*50+50,"Matricea2",getmaxwidth()-((m+1)*50),size_y_dr,false,false);
    setbkcolor(4);
    cleardevice();
    if(n==m)
        output_nn(ma,n);
    else
        output_nm(ma,n,m);
}
void generate_m1(int ma[NM][NM], int n, int m)
{
    if(win3!=1)
    {
        setcurrentwindow(win3);
        closegraph(win3);
    }
    win3= initwindow(m*50+50,n*50+50,"Matricea1",0,size_y_st,false,false);
    setbkcolor(4);
    cleardevice();
    if(n==m)
        output_nn(ma,n);
    else
        output_nm(ma,n,m);
}

int win_center=1;
void other(int ma1[NM][NM],int n1,int m1,int ma2[NM][NM],int n2,int m2,int op)
{
    if(win_center!=1)
    {
        setcurrentwindow(win_center);
        closegraph(win_center);
    }
    generate_m2(ma2,n2,m2);
    generate_m1(ma1,n1,m1);
    switch (op)
    {
    case 1://adunare
        {
            if(n1!=n2 || m1!=m2)
            {
                win_center= initwindow(200,100,"Rezultat",(getmaxwidth()-200)/2,size_y_st,false,false);
                setcurrentwindow(win_center);
                setbkcolor(4);
                cleardevice();
                bgiout<<"Imposibil";
                outstreamxy(65,40);
            }
            else
            {
                for(int i=1;i<=n1;i++)
                {
                    for(int j=1;j<=m1;j++)
                        mi[i][j]=ma1[i][j]+ma2[i][j];
                }
                if(n1==m1)
                    output_nn(mi,n1);
                else
                    output_nm(mi,n1,m1);
            }
            break;
        }
    case 2: //inmultire
        {
            if(m1!=n2)
            {
                win_center= initwindow(200,100,"Rezultat",(getmaxwidth()-200)/2,size_y_st,false,false);
                setcurrentwindow(win_center);
                setbkcolor(4);
                cleardevice();
                bgiout<<"Imposibil";
                outstreamxy(65,40);
            }
            else
            {
                win_center= initwindow(min(m1,m2)*50+50,max(n1,n2)*50+50,"Rezultat",(getmaxwidth()-(min(m1,m2)*50+50))/2,size_y_st,false,false);
                setcurrentwindow(win_center);
                setbkcolor(4);
                cleardevice();
                int  aux=0;
                for(int i=1;i<=max(n1,n2);i++)
                {
                    for(int j=1;j<=min(m1,m2);j++)
                    {
                        aux=0;
                        for(int k=1;k<=max(m1,m2);k++)
                        {
                            aux+=(ma1[i][k]*ma2[k][j]);
                            cout<<ma1[i][k]<<"*"<<ma2[k][j]<<'\n';
                        }
                        mi[i][j]=aux;
                    }
                }
                if(max(n1,n2)==min(m1,m2))
                    output_nn(mi,max(n1,n2));
                else
                    output_nm(mi,max(n1,n2),min(m1,m2));
            }
            break;
        }
    }
}
void output_vector(int v[NM][NM],int m,int n,int sizeV)
{
    int p=1;
    cleardevice();
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m && p<=sizeV;j+=2)
        {
            patrat(50*j,50*i,50);
            setfillstyle(SOLID_FILL, GREEN);
            floodfill(50*j, 50*i, 15);
            bgiout<<v[1][p];
            outstreamxy(50*j-10, 50*i-10);
            delay(150);
            setfillstyle(EMPTY_FILL, WHITE);
            floodfill(50*j+10, 50*i+10, 15);
            delay(150);
            setfillstyle(SOLID_FILL, BLACK);
            floodfill(50*j+10, 50*i+10, 15);
            p+=2;
        }

    }
    p=2;
    for(int i=1;i<=n;i++)
    {
        for(int j=2;j<=m && p<=sizeV;j+=2)
        {
            patrat(50*j,50*i,50);
            setfillstyle(SOLID_FILL, GREEN);
            floodfill(50*j, 50*i, 15);
            bgiout<<v[1][p];
            outstreamxy(50*j-10, 50*i-10);
            delay(150);
            setfillstyle(EMPTY_FILL, WHITE);
            floodfill(50*j+10, 50*i+10, 15);
            delay(150);
            setfillstyle(SOLID_FILL, BLACK);
            floodfill(50*j+10, 50*i+10, 15);
            p+=2;
        }
    }
}
void sort_vector(int v[NM][NM],int n)
{
    setcurrentwindow(win1);
    closegraph(win1);
    setcurrentwindow(win2);
    closegraph(win2);
    setcurrentwindow(win3);
    closegraph(win3);
    setcurrentwindow(win4);
    closegraph(win4);
    setcurrentwindow(win_center);
    closegraph(win_center);
    int aux=1;
    if(getmaxwidth()<(n*50+50))
    {
        aux=(n*50+50)/getmaxwidth();
        if((n*50+50)%getmaxwidth())
            aux++;
    }
    if(aux==1)
        win1=initwindow(n*50+50,aux*50+50,"Sortare",0,0,false,false);
    else
        win1=initwindow(getmaxwidth(),aux*50+50,"Sortare",0,0,false,false);
    setbkcolor(4);
    cleardevice();
    output_vector(v,(getmaxwidth()-50)/50,aux,n);
    for(int i=1;i<n;i++)
    {

        for(int j=i+1;j<=n;j++)
        {
            if(v[1][i]>v[1][j])
                swap(v[1][i],v[1][j]);
        }
    }
    cleardevice();
    setbkcolor(3);

    output_vector(v,(getmaxwidth()-50)/50,aux,n);
}
int min_max_vector(int v[NM][NM], int n, bool ok)
{
    int mini=v[1][1],maxi=v[1][1];
    for(int i=2;i<=n;i++)
    {
        mini=min(mini,v[1][i]);
        maxi=max(maxi,v[1][i]);
    }
    if(ok)
        return mini;
    else
        return maxi;
}
void afisare(int ma[NM][NM],int n,int m)
{
    if(win_center!=1)
    {
        setcurrentwindow(win_center);
        closegraph(win_center);
    }
    win_center= initwindow(m*50+50,n*50+50,"Rezultat",(getmaxwidth()-(m+50+50))/2,getmaxheight()-250-(n*50+50),false,false);
    if(n==m)
        output_nn(ma,n);
    else
        output_nm(ma,n,m);
    delay(1000);
    setcurrentwindow(win_center);
    closegraph(win_center);
}
int select()
{
    int x=-1;
    setcurrentwindow(menu);
    while(x)
    {
        if(ismouseclick(WM_LBUTTONDOWN))
        {
            clearmouseclick(WM_LBUTTONDOWN);
            x=mousex();
            setfill(SOLID_FILL,GREEN);
            floodfill(x,25,15);
            break;
        }
    }
    afisare(a[x/50].ma,a[x/50].n,a[x/50].m);
    delay(75);
    setfill(EMPTY_FILL,GREEN);
    floodfill(x,25,15);
    return x/50;
}
