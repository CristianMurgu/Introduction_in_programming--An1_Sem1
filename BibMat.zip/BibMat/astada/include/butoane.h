#ifndef BUTOANE_H
#define BUTOANE_H

#include <cstring>
#define NM 101
class butoane
{
public:
    int xL,xR,yUp,yD;
    int xc,yc;
    int activ;
    char *text;
    int lat,lung;
    void Desen();
    int click(int x,int y);
    butoane(int x,int y,char* cuv);
    virtual ~butoane();
};
void paginaCinMat();

struct matrice
{
    char nume;
    int n,m;
    int ma[NM][NM];
    bool tip;
};

void inserare(char x,char v[101],int &n);
void convertNrInCh(int x,char v[101]);
void afisMatrice(matrice A,int xx,int yy);
void CitireTastaturaM(matrice &x,int menu);
void CitireFisiertxtM(matrice &x);
void CitireFisierM(matrice &x);

void CitireTastaturaV(matrice &x,int menu);
void CitireFisiertxtV(matrice &x);
void CitireFisierV(matrice &x);
void patrat(int x,int y);
#endif // BUTOANE_H
