#include <bits/stdc++.h>
#include <graphics.h>
#include <winbgim.h>
#include <algorithm>
#include "butoane.h"
#include "MMSystem.h"
#define NM 101

using namespace std;
int menu,win1=1,win2=1,win3=1,win4=1;
int win_center=1;
int size_y_dr,size_y_st;
int ctM=0,ctV=0;
int mi[NM][NM],n;
int select1();
void generate_inversa(int ma[NM][NM],int n);
void output_nn(int m[NM][NM],int n);
void afisare_min_max(int v[NM][NM],int n,bool ok);
void generate_transpusa(int ma[NM][NM], int n);
void generate_eliminari(int ma[NM][NM], int &n, int &m, bool ok);
int det(int m[NM][NM], int n);
void other(int ma1[NM][NM],int n1,int m1,int ma2[NM][NM],int n2,int m2,int op);
void sort_vector(int v[NM][NM],int n);
void eroare()
{

    int eror= initwindow(200,100,"Eroare",(getmaxwidth()-200)/2,getmaxheight()-350,false,false);
    setcurrentwindow(eror);
    setbkcolor(4);
    cleardevice();
    bgiout<<"Imposibil";
    outstreamxy(65,40);
    delay(750);
    closegraph(eror);
}
int xmx=getmaxwidth(),ymx=250,dif=xmx/7;
int i=0;
matrice vM[7];
matrice vV[7];
int nvM=0;
butoane citesteM(xmx/4-dif,165,"Citeste o matrice");
butoane citesteV(xmx/4*2-dif,165,"Citeste un vector");
butoane operatiiM(xmx/4*3-dif,165,"Operatii matrici");
butoane operatiiV(xmx/4*4-dif,165,"Operatii vectori");

butoane Mcitiretaste(xmx/4-dif,195," De la tastatura ");
butoane Mcitirefisiertxt(xmx/4-dif,135," Din fisier text ");
butoane Mcitirefisierf(xmx/4-dif,105,"    Din fisier   ");

butoane determinant(xmx/4*3-dif,195,"   Determinant  ");
butoane inversa1(xmx/4*3-dif,135,"    Inversa     ");
butoane produsmatrici(xmx/4*3-dif,105," Produs matrici ");
butoane transpusa1(xmx/4*3-dif+strlen("    Inversa      ")*10,135,"    Transpusa     ");
butoane eliminarelinie(xmx/4*3-dif-strlen("    Inversa      ")*10,165," Eliminare linie  ");
butoane eliminarecoloana(xmx/4*3-dif+strlen("    Inversa      ")*10,165," Eliminare coloana");
butoane adunare(xmx/4*3-dif-17*10,135," Adunare matrici  ");

butoane Vcitiretaste(xmx/4*2-dif,195," De la tastatura ");
butoane Vcitirefisiertxt(xmx/4*2-dif,135," Din fisier text ");
butoane Vcitirefisierf(xmx/4*2-dif,105,"    Din fisier   ");

butoane elementmaxim(xmx/4*4-dif,195,"Elementul maxim ");
butoane elementminim(xmx/4*4-dif,135,"Elementul minim ");
butoane sortare(xmx/4*4-dif,105,"    Sortare     ");


void elementevM()
{
    for(int i=1; i<=nvM; i++)
    {
        line(i*75,0,i*75,75);
        bgiout<<vM[i-1].nume;
        if(vM[i-1].tip==1)
            bgiout<<"(M)";
        else
            bgiout<<"(V)";
        outstreamxy(i*75-50,25);
    }
}
void showbutoane()
{
    elementevM();
    line(0,75,xmx,75);

    if(citesteM.activ)
        citesteM.Desen();
    if(citesteV.activ)
        citesteV.Desen();
    if(operatiiM.activ)
    {
        operatiiM.Desen();
    }
    if(operatiiV.activ)
        operatiiV.Desen();

    if(Mcitiretaste.activ)
        Mcitiretaste.Desen();
    if(Mcitirefisierf.activ)
        Mcitirefisierf.Desen();
    if(Mcitirefisiertxt.activ)
        Mcitirefisiertxt.Desen();

    if(Vcitiretaste.activ)
        Vcitiretaste.Desen();
    if(Vcitirefisierf.activ)
        Vcitirefisierf.Desen();
    if(Vcitirefisiertxt.activ)
        Vcitirefisiertxt.Desen();

    if(determinant.activ)
        determinant.Desen();
    if(inversa1.activ)
        inversa1.Desen();
    if(produsmatrici.activ)
        produsmatrici.Desen();
    if(transpusa1.activ)
        transpusa1.Desen();
    if(eliminarecoloana.activ)
        eliminarecoloana.Desen();
    if(eliminarelinie.activ)
        eliminarelinie.Desen();
    if(adunare.activ)
        adunare.Desen();

    if(elementmaxim.activ)
        elementmaxim.Desen();
    if(elementminim.activ)
        elementminim.Desen();
    if(sortare.activ)
        sortare.Desen();
}
void init()
{
    citesteM.activ=1;
    citesteV.activ=1;
    operatiiM.activ=1;
    operatiiV.activ=1;
    Mcitirefisierf.activ=0;
    Vcitirefisierf.activ=0;
    determinant.activ=0;
    elementmaxim.activ=0;
}
void clickbut(int x,int y,int menu)
{
    PlaySound(TEXT("Mouse-Click.wav"), NULL,SND_ASYNC);
    if(citesteM.click(x,y) && Mcitirefisierf.activ==0)
    {
        Mcitirefisierf.activ=1;
        Mcitirefisiertxt.activ=1;
        Mcitiretaste.activ=1;
        showbutoane();
        setfillstyle(LTSLASH_FILL,GREEN);
        floodfill(xmx/4-dif+15,165,15);
    }
    else if(citesteM.click(x,y) && Mcitirefisierf.activ==1)
    {
        Mcitirefisierf.activ=0;
        Mcitirefisiertxt.activ=0;
        Mcitiretaste.activ=0;
        cleardevice();
    }

    if(citesteV.click(x,y) && Vcitirefisierf.activ==0)
    {
        Vcitirefisierf.activ=1;
        Vcitirefisiertxt.activ=1;
        Vcitiretaste.activ=1;
        showbutoane();
        setfillstyle(LTSLASH_FILL,GREEN);
        floodfill(xmx/4*2-dif+15,165,15);
    }
    else if(citesteV.click(x,y) && Vcitirefisierf.activ==1)
    {
        Vcitirefisierf.activ=0;
        Vcitirefisiertxt.activ=0;
        Vcitiretaste.activ=0;
        cleardevice();
    }

    if(operatiiM.click(x,y) && determinant.activ==0)
    {
        determinant.activ=1;
        inversa1.activ=1;
        produsmatrici.activ=1;
        transpusa1.activ=1;
        eliminarecoloana.activ=1;
        eliminarelinie.activ=1;
        adunare.activ=1;
        showbutoane();
        setfillstyle(LTSLASH_FILL,GREEN);
        floodfill(xmx/4*3-dif+5,165-5,15);
    }
    else if(operatiiM.click(x,y) && determinant.activ==1)
    {
        determinant.activ=0;
        inversa1.activ=0;
        produsmatrici.activ=0;
        transpusa1.activ=0;
        eliminarecoloana.activ=0;
        eliminarelinie.activ=0;
        adunare.activ=0;
        cleardevice();
    }

    if(operatiiV.click(x,y) && elementmaxim.activ==0)
    {
        elementmaxim.activ=1;
        sortare.activ=1;
        elementminim.activ=1;
        showbutoane();
        setfillstyle(LTSLASH_FILL,GREEN);
        floodfill(xmx/4*4-dif,165,15);
    }
    else if(operatiiV.click(x,y) && elementmaxim.activ==1)
    {
        elementmaxim.activ=0;
        sortare.activ=0;
        elementminim.activ=0;
        cleardevice();
    }
    if(Mcitiretaste.click(x,y) && Mcitiretaste.activ==1)
    {
        CitireTastaturaM(vM[nvM],menu);
        vM[nvM].tip=1;
        nvM++;
        line(nvM*75,0,nvM*75,75);
        bgiout<<vM[nvM-1].nume;
        bgiout<<"(M)";
        outstreamxy(nvM*75-50,25);
    }
    if(Mcitirefisiertxt.click(x,y) && Mcitirefisiertxt.activ==1 && ctM<2)
    {
        ctM++;

        CitireFisiertxtM(vM[nvM]);
        vM[nvM].tip=1;
        nvM++;
        line(nvM*75,0,nvM*75,75);
        bgiout<<vM[nvM-1].nume;
        bgiout<<"(M)";

        outstreamxy(nvM*75-50,25);
    }
    if(Mcitirefisierf.click(x,y)&& Mcitirefisierf.activ==1)
    {
        CitireFisierM(vM[nvM]);

        if(vM[nvM].nume!=NULL)
        {
            vM[nvM].tip=1;
            nvM++;
            line(nvM*75,0,nvM*75,75);
            bgiout<<vM[nvM-1].nume;

            bgiout<<"(M)";
            outstreamxy(nvM*75-50,25);
        }
    }
    if(Vcitirefisierf.click(x,y)&& Vcitirefisierf.activ==1)
    {
        CitireFisierV(vM[nvM]);

        if(vM[nvM].nume!=NULL)
        {
            vM[nvM].tip=0;
            nvM++;
            line(nvM*75,0,nvM*75,75);
            bgiout<<vM[nvM-1].nume;

            bgiout<<"(V)";
            outstreamxy(nvM*75-50,25);
        }
    }


    if(Vcitiretaste.click(x,y) && Vcitiretaste.activ==1)
    {
        CitireTastaturaV(vM[nvM],menu);
        vM[nvM].tip=0;
        nvM++;
        line(nvM*75,0,nvM*75,75);
        bgiout<<vM[nvM-1].nume;
        bgiout<<"(V)";
        outstreamxy(nvM*75-50,25);
    }
    if(Vcitirefisiertxt.click(x,y) && Vcitirefisiertxt.activ==1 && ctV<2)
    {
        CitireFisiertxtV(vM[nvM]);
        vM[nvM].tip=0;
        if(vM[nvM].nume!=NULL)
        {
            ctV++;
            nvM++;
            line(nvM*75,0,nvM*75,75);
            bgiout<<vM[nvM-1].nume;
            bgiout<<"(V)";
            outstreamxy(nvM*75-50,25);
        }
    }
    if(inversa1.click(x,y) && inversa1.activ==1)
    {
        int f=select1();
        if(vM[f].n==vM[f].m && det(vM[f].ma,vM[f].n))
            generate_inversa(vM[f].ma,vM[f].n);
        else
            eroare();
        setcurrentwindow(menu);
    }
    if(elementmaxim.click(x,y) && elementmaxim.activ==1)
    {
        int f=select1();
        afisare_min_max(vM[f].ma,vM[f].m,0);
        setcurrentwindow(menu);
    }
    if(elementminim.click(x,y) && elementminim.activ==1)
    {
        int f=select1();
        afisare_min_max(vM[f].ma,vM[f].m,1);
        setcurrentwindow(menu);
    }
    if(transpusa1.click(x,y) && transpusa1.activ==1)
    {
        int f=select1();
        if(vM[f].m==vM[f].n)
            generate_transpusa(vM[f].ma,vM[f].n);
        else
            eroare();
        setcurrentwindow(menu);
    }
    if(eliminarecoloana.click(x,y) && eliminarecoloana.activ==1)
    {
        int f=select1();
        if(vM[f].m>1)
            generate_eliminari(vM[f].ma,vM[f].n,vM[f].m,0);
        else
            eroare();
        setcurrentwindow(menu);
    }
    if(eliminarelinie.click(x,y) && eliminarelinie.activ==1)
    {
        int f=select1();
        if(vM[f].n>1)
            generate_eliminari(vM[f].ma,vM[f].n,vM[f].m,1);
        setcurrentwindow(menu);
    }
    if(determinant.click(x,y) && determinant.activ==1)
    {
        int f=select1();
        if(vM[f].n==vM[f].m)
        {
            int rez=det(vM[f].ma,vM[f].n);
            bgiout<<rez;
            outstreamxy(xmx/4*3-dif+100,195);

        }
        else
            eroare();
        setcurrentwindow(menu);
    }
    if(produsmatrici.click(x,y)&& produsmatrici.activ==1)
    {
        int f=select1(),g=select1();
        other(vM[f].ma,vM[f].n,vM[f].m,vM[g].ma,vM[g].n,vM[g].m,2);
        setcurrentwindow(menu);
    }
    if(adunare.click(x,y) && adunare.activ==1)
    {
        int f=select1(),g=select1();
        other(vM[f].ma,vM[f].n,vM[f].m,vM[g].ma,vM[g].n,vM[g].m,1);
        setcurrentwindow(menu);
    }
    if(sortare.click(x,y) && sortare.activ==1)
    {
        int f=select1();
        if(vM[f].tip==0)
            sort_vector(vM[f].ma,vM[f].m);
        else
            eroare();
        setcurrentwindow(menu);
    }

}

void output_nm(int m[NM][NM],int n, int m1);
void output_nn(int m[NM][NM],int n);
void elimLine(int ma[NM][NM],int &n,int m)
{
    int l,y=-1;
    while(y)
    {
        if(ismouseclick(WM_LBUTTONDOWN))
        {
            clearmouseclick(WM_LBUTTONDOWN);
            y=mousey();
            break;
        }
    }
    l=y/50;
    for(int i=1; i<=m; i++)
    {
        setfillstyle(LTBKSLASH_FILL, GREEN);
        floodfill(50*i+10, 50*l+10, 15);
        delay(150);
    }
    for(int i=l+1; i<=n; i++)
    {
        for(int j=1; j<=m; j++)
            ma[i-1][j]=ma[i][j];
    }
    if(n-1==m)
        output_nn(ma,n-1);
    else
        output_nm(ma,n-1,m);
    n--;
}
void elimCol(int ma[NM][NM],int n,int &m)
{
    int c,x=-1;
    while(x)
    {
        if(ismouseclick(WM_LBUTTONDOWN))
        {
            clearmouseclick(WM_LBUTTONDOWN);
            x=mousex();
            break;
        }
    }
    c=x/50;
    for(int i=1; i<=n; i++)
    {
        setfillstyle(LTBKSLASH_FILL, GREEN);
        floodfill(50*c+10, 50*i+10, 15);
        delay(75);
    }
    for(int i=1; i<=n; i++)
    {
        for(int j=c+1; j<=m; j++)
            ma[i][j-1]=ma[i][j];
    }
    if(n==m-1)
        output_nn(ma,n);
    else
        output_nm(ma,n,m-1);
    m--;
}
void output_nm(int m[NM][NM],int n, int m1)
{
    cleardevice();
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=m1; j+=2)
        {
            patrat(50*j,50*i);
            setfillstyle(SOLID_FILL, GREEN);
            floodfill(50*j, 50*i, 15);
            bgiout<<m[i][j];
            outstreamxy(50*j-10, 50*i-10);
            delay(150);
            setfillstyle(EMPTY_FILL, WHITE);
            floodfill(50*j+10, 50*i+10, 15);
            delay(150);
            setfillstyle(SOLID_FILL, BLACK);
            floodfill(50*j+10, 50*i+10, 15);
        }

    }
    for(int i=1; i<=n; i++)
    {
        for(int j=2; j<=m1; j+=2)
        {
            patrat(50*j,50*i);
            setfillstyle(SOLID_FILL, GREEN);
            floodfill(50*j, 50*i, 15);
            bgiout<<m[i][j];
            outstreamxy(50*j-10, 50*i-10);
            delay(150);
            setfillstyle(EMPTY_FILL, WHITE);
            floodfill(50*j+10, 50*i+10, 15);
            delay(150);
            setfillstyle(SOLID_FILL, BLACK);
            floodfill(50*j+10, 50*i+10, 15);
        }
    }
}
void output_nn(int m[NM][NM],int n)
{
    cleardevice();
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<i; j++)
        {
            patrat(50*j,50*i);
            setfillstyle(SOLID_FILL, GREEN);
            floodfill(50*j, 50*i, 15);
            bgiout<<m[i][j];
            outstreamxy(50*j-10, 50*i-10);
            delay(150);
            setfillstyle(EMPTY_FILL, WHITE);
            floodfill(50*j+10, 50*i+10, 15);
            delay(150);
            setfillstyle(SOLID_FILL, BLACK);
            floodfill(50*j+10, 50*i+10, 15);
        }
    }
    for(int i=1; i<=n; i++)
    {
        patrat(50*i,50*i);
        setfillstyle(SOLID_FILL, GREEN);
        floodfill(50*i, 50*i, 15);
        bgiout<<m[i][i];
        outstreamxy(50*i-10, 50*i-10);
        delay(150);
        setfillstyle(EMPTY_FILL, WHITE);
        floodfill(50*i+10, 50*i+10, 15);
        delay(150);
        setfillstyle(SOLID_FILL, BLACK);
        floodfill(50*i+10, 50*i+10, 15);
    }
    for(int i=1; i<=n; i++)
    {
        for(int j=i+1; j<=n; j++)
        {
            patrat(50*j,50*i);
            setfillstyle(SOLID_FILL, GREEN);
            floodfill(50*j, 50*i, 15);
            bgiout<<m[i][j];
            outstreamxy(50*j-10, 50*i-10);
            delay(150);
            setfillstyle(EMPTY_FILL, WHITE);
            floodfill(50*j+10, 50*i+10, 15);
            delay(150);
            setfillstyle(SOLID_FILL, BLACK);
            floodfill(50*j+10, 50*i+10, 15);
        }
    }
}
bool t=0;
void transpusa(int m[NM][NM], int n, bool ok)
{

    for(int i=1; i<=n && t==0; i++)
    {
        m[i][i]=m[i][i];
        for(int j=i+1; j<=n; j++)
        {
            if(i!=j)
                swap(m[i][j],m[j][i]);
        }
    }
    t=1;
    if(ok==1)
        output_nn(m,n);
}

int detij(int m[NM][NM],int l, int c, int n)
{
    int a[NM][NM];
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            if(i>=l+1)
                a[i-1][j]=m[i][j];
            else
                a[i][j]=m[i][j];
        }
    }
    for(int i=1; i<=n; i++)
    {
        for(int j=c+1; j<=n; j++)
            a[i][j-1]=a[i][j];
    }
    return det(a,n-1);
}

int det(int m[NM][NM], int n)
{
    switch (n)
    {
    case 1:
        return m[1][1];
    case 2:
        return m[1][1]*m[2][2]-m[2][1]*m[1][2];
    case 3:
    {
        int sf=0,df=0,aux1,aux2;
        for(int i=n+1; i<=2*n-1; i++)
        {
            for(int j=1; j<=n; j++)
                m[i][j]=m[i-n][j];
        }
        for(int i=0; i<n; i++)
        {
            aux1=1;
            aux2=1;
            for(int j=1, k=n; j<=n && k>=1; j++, k--)
            {
                aux1=aux1*m[j+i][j];
                aux2=aux2*m[j+i][k];
            }
            sf=sf+aux1;
            df=df+aux2;
        }
        return sf-df;
    }
    default:
    {
        int s=0;
        for(int i=1; i<=n; i++)
            s=s+pow(-1,i+1)*m[1][i]*detij(m,1,i,n);
        return s;
    }
    }
}

void inversa(int m[NM][NM], int n)
{
    int d=det(m,n);
    transpusa(m,n,0);
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
            mi[i][j]=pow(-1,i+j)*detij(m,i,j,n)/d;
    }
    output_nn(mi,n);
}

void generate_inversa(int ma[NM][NM],int n)
{
    if(win1!=1)
    {
        setcurrentwindow(win1);
        closegraph(win1);
    }
    if(size_y_st+n*50+50>(getmaxheight()-250))
    {
        if(win3!=1)
        {
            setcurrentwindow(win3);
            closegraph(win3);
        }
        size_y_st=0;
    }
    win1= initwindow(n*50+50,n*50+50,"inversa matricii", 0, 0, false, false);
    size_y_st+=n*50+50;
    setbkcolor(4);
    cleardevice();
    inversa(ma,n);
    setcurrentwindow(menu);//pt fiecare final de gen
}

void generate_transpusa(int ma[NM][NM], int n)
{
    if(win2!=1)
    {
        setcurrentwindow(win2);
        closegraph(win2);
    }
    if(size_y_dr+n*50+50>(getmaxheight()-250))
    {
        if(win4!=1)
        {
            setcurrentwindow(win4);
            closegraph(win4);
        }
        size_y_dr=0;
    }
    win2= initwindow(n*50+50,n*50+50,"transpusa matricii",getmaxwidth()-(n*50+50),0,false,false);
    size_y_dr+=n*50+50;
    setbkcolor(4);
    cleardevice();
    transpusa(ma,n,1);
    setcurrentwindow(menu);
}

void generate_eliminari(int ma[NM][NM], int &n, int &m, bool ok)
{
    if(win3!=1)
    {
        setcurrentwindow(win3);
        closegraph(win3);
    }
    if(ok)
    {
        if(size_y_st+n*50+50>(getmaxheight()-250))
        {
            if(win1!=1)
            {
                setcurrentwindow(win1);
                closegraph(win1);
            }
            size_y_st=0;
        }
        win3= initwindow(m*50+50,n*50+50,"eliminari linie",0,size_y_st,false,false);
        size_y_st+=n*50+50;
    }
    else
    {
        if(size_y_dr+n*50+50>(getmaxheight()-250))
        {
            if(win2!=1)
            {
                setcurrentwindow(win2);
                closegraph(win2);
            }
            size_y_dr=0;
            ok=1;
        }
        win3= initwindow(m*50+50,n*50+50,"eliminari coloana",getmaxwidth()-((m+1)*50),size_y_dr,false,false);
        if(ok)
            size_y_dr+=n*50+50;
    }
    setbkcolor(4);
    cleardevice();
    output_nm(ma,n,m);
    if(ok)
        elimLine(ma,n,m);
    else
        elimCol(ma,n,m);
}

void generate_m2(int ma[NM][NM], int n, int m)
{
    if(win4!=1)
    {
        setcurrentwindow(win4);
        closegraph(win4);
    }
    if((win1!=1 || win2!=1) && (max(size_y_dr,size_y_st)+n*50+50)>getmaxheight())
    {
        setcurrentwindow(win1);
        closegraph(win1);
        setcurrentwindow(win2);
        closegraph(win2);
        setcurrentwindow(win3);
        closegraph(win3);
        setcurrentwindow(win4);
        closegraph(win4);
        setcurrentwindow(win_center);
        closegraph(win_center);
        win1=win2=1;
        size_y_dr=size_y_st=0;

    }
    size_y_st=max(size_y_dr,size_y_st);
    size_y_dr=max(size_y_dr,size_y_st);
    win4= initwindow(m*50+50,n*50+50,"Matricea2",getmaxwidth()-((m+1)*50),size_y_dr,false,false);
    setbkcolor(4);
    cleardevice();
    if(n==m)
        output_nn(ma,n);
    else
        output_nm(ma,n,m);
}
void generate_m1(int ma[NM][NM], int n, int m)
{
    if(win3!=1)
    {
        setcurrentwindow(win3);
        closegraph(win3);
    }
    win3= initwindow(m*50+50,n*50+50,"Matricea1",0,size_y_st,false,false);
    setbkcolor(4);
    cleardevice();
    if(n==m)
        output_nn(ma,n);
    else
        output_nm(ma,n,m);
}
void other(int ma1[NM][NM],int n1,int m1,int ma2[NM][NM],int n2,int m2,int op)
{
    if(win_center!=1)
    {
        setcurrentwindow(win_center);
        closegraph(win_center);
    }
    generate_m2(ma2,n2,m2);
    generate_m1(ma1,n1,m1);
    switch (op)
    {
    case 1://adunare
    {
        if(n1!=n2 || m1!=m2)
        {
            win_center= initwindow(200,100,"Rezultat",(getmaxwidth()-200)/2,size_y_st,false,false);
            setcurrentwindow(win_center);
            setbkcolor(4);
            cleardevice();
            bgiout<<"Imposibil";
            outstreamxy(65,40);
        }
        else
        {
            win_center= initwindow(m1*50+50,n1*50+50,"Rezultat",(getmaxwidth()-m1*50+50)/2,size_y_st,false,false);
            setcurrentwindow(win_center);
            setbkcolor(4);
            cleardevice();
            for(int i=1; i<=n1; i++)
            {
                for(int j=1; j<=m1; j++)
                    mi[i][j]=ma1[i][j]+ma2[i][j];
            }
            if(n1==m1)
                output_nn(mi,n1);
            else
                output_nm(mi,n1,m1);
        }
        break;
    }
    case 2: //inmultire
    {
        if(m1!=n2)
        {
            win_center= initwindow(200,100,"Rezultat",(getmaxwidth()-200)/2,size_y_st,false,false);
            setcurrentwindow(win_center);
            setbkcolor(4);
            cleardevice();
            bgiout<<"Imposibil";
            outstreamxy(65,40);
        }
        else
        {
            win_center= initwindow(min(m1,m2)*50+50,max(n1,n2)*50+50,"Rezultat",(getmaxwidth()-(min(m1,m2)*50+50))/2,size_y_st,false,false);
            setcurrentwindow(win_center);
            setbkcolor(4);
            cleardevice();
            int  aux=0;
            for(int i=1; i<=max(n1,n2); i++)
            {
                for(int j=1; j<=min(m1,m2); j++)
                {
                    aux=0;
                    for(int k=1; k<=max(m1,m2); k++)
                    {
                        aux+=(ma1[i][k]*ma2[k][j]);
                        //cout<<ma1[i][k]<<"*"<<ma2[k][j]<<'\n';
                    }
                    mi[i][j]=aux;
                }
            }
            if(max(n1,n2)==min(m1,m2))
                output_nn(mi,max(n1,n2));
            else
                output_nm(mi,max(n1,n2),min(m1,m2));
        }
        break;
    }
    }
}
void output_vector(int v[NM][NM],int m,int n,int sizeV,bool o,int val)
{
    int p=1;
    cleardevice();
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=m && p<=sizeV; j+=2)
        {
            patrat(50*j,50*i);
            setfillstyle(SOLID_FILL, GREEN);
            floodfill(50*j, 50*i, 15);
            bgiout<<v[1][p];
            outstreamxy(50*j-10, 50*i-10);
            delay(150);
            setfillstyle(EMPTY_FILL, WHITE);
            floodfill(50*j+10, 50*i+10, 15);
            delay(150);
            setfillstyle(SOLID_FILL, BLACK);
            floodfill(50*j+10, 50*i+10, 15);
            if(o && val==v[1][p])
            {
                setfillstyle(SOLID_FILL,BLUE);
                floodfill(50*j+10,50*i+10,15);
            }
            p+=2;
        }

    }
    p=2;
    for(int i=1; i<=n; i++)
    {
        for(int j=2; j<=m && p<=sizeV; j+=2)
        {
            patrat(50*j,50*i);
            setfillstyle(SOLID_FILL, GREEN);
            floodfill(50*j, 50*i, 15);
            bgiout<<v[1][p];
            outstreamxy(50*j-10, 50*i-10);
            delay(150);
            setfillstyle(EMPTY_FILL, WHITE);
            floodfill(50*j+10, 50*i+10, 15);
            delay(150);
            setfillstyle(SOLID_FILL, BLACK);
            floodfill(50*j+10, 50*i+10, 15);
            if(o && val==v[1][p])
            {
                setfillstyle(SOLID_FILL,BLUE);
                floodfill(50*j,50*i,15);
            }
            p+=2;
        }
    }
}
void sort_vector(int v[NM][NM],int n)
{
    setcurrentwindow(win1);
    closegraph(win1);
    setcurrentwindow(win2);
    closegraph(win2);
    setcurrentwindow(win3);
    closegraph(win3);
    setcurrentwindow(win4);
    closegraph(win4);
    setcurrentwindow(win_center);
    closegraph(win_center);
    size_y_dr=size_y_st=0;
    int aux=1;
    if(getmaxwidth()<(n*50+50))
    {
        aux=(n*50+50)/getmaxwidth();
        if((n*50+50)%getmaxwidth())
            aux++;
    }
    if(aux==1)
        win1=initwindow(n*50+50,aux*50+50,"Sortare",0,0,false,false);
    else
        win1=initwindow(getmaxwidth(),aux*50+50,"Sortare",0,0,false,false);
    setbkcolor(4);
    cleardevice();
    output_vector(v,(getmaxwidth()-50)/50,aux,n,0,1);
    for(int i=1; i<n; i++)
    {

        for(int j=i+1; j<=n; j++)
        {
            if(v[1][i]>v[1][j])
                swap(v[1][i],v[1][j]);
        }
    }
    cleardevice();
    setbkcolor(3);

    output_vector(v,(getmaxwidth()-50)/50,aux,n,0,1);
}
int min_max_vector(int v[NM][NM], int n, bool ok)
{
    int mini=v[1][1],maxi=v[1][1];
    for(int i=2; i<=n; i++)
    {
        mini=min(mini,v[1][i]);
        maxi=max(maxi,v[1][i]);
    }
    if(ok)
        return mini;
    else
        return maxi;
}
void afisare_min_max(int v[NM][NM],int n,bool ok)
{
    int aux=1,val;
    setcurrentwindow(win1);
    closegraph(win1);
    setcurrentwindow(win2);
    closegraph(win2);
    setcurrentwindow(win3);
    closegraph(win3);
    setcurrentwindow(win4);
    closegraph(win4);
    setcurrentwindow(win_center);
    closegraph(win_center);
    size_y_dr=size_y_st=0;
    val=min_max_vector(v,n,ok);
    if(getmaxwidth()<(n*50+50))
    {
        aux=(n*50+50)/getmaxwidth();
        if((n*50+50)%getmaxwidth())
            aux++;
    }
    if(aux==1)
        win1=initwindow(n*50+50,aux*50+50,"Element",0,0,false,false);
    else
        win1=initwindow(getmaxwidth(),aux*50+50,"Element",0,0,false,false);
    setbkcolor(4);
    cleardevice();
    output_vector(v,(getmaxwidth()-50)/50,aux,n,1,val);
    setcurrentwindow(menu);

}
void afisare(int ma[NM][NM],int n,int m)
{
    if(win_center!=1)
    {
        setcurrentwindow(win_center);
        closegraph(win_center);
    }
    win_center= initwindow(m*50+50,n*50+50,"Tabloul selectat",(getmaxwidth()-(m+50+50))/2,getmaxheight()-250-(n*50+50),false,false);
    if(n==m)
        output_nn(ma,n);
    else
        output_nm(ma,n,m);
    delay(1000);
    setcurrentwindow(win_center);
    closegraph(win_center);
}
int select1()
{
    int x=-1,y=-1;
    setcurrentwindow(menu);
    while(x)
    {
        if(nvM==0)
        {
            eroare();
            return 0;
        }
        else if(ismouseclick(WM_LBUTTONDOWN))
        {
            clearmouseclick(WM_LBUTTONDOWN);
            x=mousex();
            y=mousey();
            if(y>=0 && y<=75 && nvM && x<=75*nvM)
            {
                setfillstyle(SOLID_FILL,GREEN);
                floodfill(x,25,15);
                break;
            }
        }
    }
    afisare(vM[x/75].ma,vM[x/75].n,vM[x/75].m);//modif
    delay(75);
    setcurrentwindow(menu);
    setfillstyle(EMPTY_FILL,GREEN);
    floodfill(x,25,15);
    return x/75;
}
int main()
{
    menu=initwindow(getmaxwidth(),250,"Menu",0,getmaxheight()-250,false,true);
    init();
    setcurrentwindow(menu);
    int x=1,y;
    while(1)
    {
        showbutoane();
        if(ismouseclick(WM_LBUTTONDOWN))
        {
            clearmouseclick(WM_LBUTTONDOWN);
            x=mousex();
            y=mousey();
            clickbut(x,y,menu);
        }

    }
    return 0;
}
